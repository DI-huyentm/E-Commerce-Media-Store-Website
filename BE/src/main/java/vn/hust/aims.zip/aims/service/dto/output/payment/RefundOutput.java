package vn.hust.aims.service.dto.output.payment;

public class RefundOutput {

}
